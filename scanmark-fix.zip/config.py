from dotenv import load_dotenv
import os
from datetime import timedelta

load_dotenv()

# Supabase Configuration
SUPABASE_URL = os.getenv('SUPABASE_URL')
SUPABASE_KEY = os.getenv('SUPABASE_KEY')

# App Configuration
SECRET_KEY = os.getenv('SECRET_KEY', os.urandom(24).hex())
DEBUG = os.getenv('DEBUG', 'False').lower() == 'true'

# Session Configuration
SESSION_TYPE = 'filesystem'
PERMANENT_SESSION_LIFETIME = timedelta(days=1)

# Google Calendar Configuration
GOOGLE_CLIENT_ID = os.getenv('GOOGLE_CLIENT_ID')
GOOGLE_CLIENT_SECRET = os.getenv('GOOGLE_CLIENT_SECRET')
GOOGLE_REDIRECT_URI = os.getenv('GOOGLE_REDIRECT_URI')

# Campus Location Configuration
CAMPUS_LOCATIONS = [
    {
        'name': 'Main Campus',
        'center': {'lat': float(os.getenv('CAMPUS_LAT', '0')), 'lng': float(os.getenv('CAMPUS_LNG', '0'))},
        'radius': float(os.getenv('CAMPUS_RADIUS', '100'))  # meters
    }
]

# OpenAI Configuration for AI Insights
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')

# Email Configuration
SMTP_SERVER = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
SMTP_PORT = int(os.getenv('SMTP_PORT', '587'))
SMTP_USERNAME = os.getenv('SMTP_USERNAME')
SMTP_PASSWORD = os.getenv('SMTP_PASSWORD')
SMTP_FROM_EMAIL = os.getenv('SMTP_FROM_EMAIL')

# QR Code Configuration
QR_CODE_EXPIRY = timedelta(hours=1)
QR_CODE_SIZE = 10  # Scale factor for QR code size

# Cache Configuration
CACHE_TYPE = 'filesystem'
CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cache')
CACHE_DEFAULT_TIMEOUT = 300  # 5 minutes

# Report Configuration
REPORT_FORMATS = ['pdf', 'csv', 'xlsx']
MAX_EXPORT_ROWS = 10000
