from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from dataclasses import dataclass
from postgrest import PostgrestClient
from config import SUPABASE_URL, SUPABASE_KEY
import json

# Initialize Supabase client
supabase = PostgrestClient(
    base_url=f"{SUPABASE_URL}/rest/v1",
    headers={
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}"
    }
)

@dataclass
class Session:
    id: str
    name: str
    faculty: str
    branch: str
    semester: str
    active: bool
    created_at: datetime
    admin_id: str
    attendances: Optional[List[Dict[str, Any]]] = None

    @classmethod
    def create(cls, name: str, faculty: str, branch: str, semester: str, admin_id: str) -> 'Session':
        """Create a new session"""
        data = {
            'name': name,
            'faculty': faculty,
            'branch': branch,
            'semester': semester,
            'active': True,
            'admin_id': admin_id
        }
        result = supabase.table('sessions').insert(data).execute()
        return cls(**result.data[0])

    @classmethod
    def get_by_id(cls, session_id: str) -> Optional['Session']:
        """Get session by ID"""
        result = supabase.table('sessions').select('*').eq('id', session_id).execute()
        return cls(**result.data[0]) if result.data else None

    @classmethod
    def get_admin_sessions(cls, admin_id: str) -> List['Session']:
        """Get all sessions for an admin"""
        result = supabase.table('sessions').select('*').eq('admin_id', admin_id).execute()
        return [cls(**data) for data in result.data]

    def add_attendance(self, student_id: str, student_name: str, location: dict) -> bool:
        """Add attendance record to session"""
        data = {
            'session_id': self.id,
            'student_id': student_id,
            'student_name': student_name,
            'location': json.dumps(location)
        }
        try:
            supabase.table('attendance').insert(data).execute()
            return True
        except Exception as e:
            print(f"Error adding attendance: {e}")
            return False

    def get_attendance_records(self) -> List[Dict[str, Any]]:
        """Get all attendance records for this session"""
        result = supabase.table('attendance').select('*').eq('session_id', self.id).execute()
        return result.data

    def get_attendance_stats(self) -> Dict[str, Any]:
        """Get attendance statistics for this session"""
        records = self.get_attendance_records()
        total_students = len(set(r['student_id'] for r in records))
        return {
            'total_students': total_students,
            'total_records': len(records),
            'attendance_dates': sorted(set(r['created_at'][:10] for r in records))
        }

@dataclass
class Student:
    id: str
    name: str
    attendance_records: Optional[List[Dict[str, Any]]] = None

    @classmethod
    def get_attendance_history(cls, student_id: str) -> List[Dict[str, Any]]:
        """Get attendance history for a student"""
        result = supabase.table('attendance').select('*').eq('student_id', student_id).execute()
        return result.data

    @classmethod
    def get_performance_stats(cls, student_id: str) -> Dict[str, Any]:
        """Get performance statistics for a student"""
        attendance = supabase.table('attendance').select('*').eq('student_id', student_id).execute()
        performance = supabase.table('student_performance').select('*').eq('student_id', student_id).execute()
        
        total_sessions = len(set(r['session_id'] for r in attendance.data))
        total_attendance = len(attendance.data)
        
        return {
            'total_sessions': total_sessions,
            'total_attendance': total_attendance,
            'attendance_percentage': (total_attendance / total_sessions * 100) if total_sessions > 0 else 0,
            'performance_records': performance.data
        }

@dataclass
class Admin:
    username: str
    password_hash: str
    created_at: datetime

    @classmethod
    def create(cls, username: str, password_hash: str) -> 'Admin':
        """Create a new admin"""
        data = {
            'username': username,
            'password_hash': password_hash
        }
        result = supabase.table('admins').insert(data).execute()
        return cls(**result.data[0])

    @classmethod
    def get_by_username(cls, username: str) -> Optional['Admin']:
        """Get admin by username"""
        result = supabase.table('admins').select('*').eq('username', username).execute()
        return cls(**result.data[0]) if result.data else None

@dataclass
class QRToken:
    token: str
    session_id: str
    created_at: datetime
    expires_at: datetime

    @classmethod
    def create(cls, session_id: str, expiry_hours: int = 1) -> 'QRToken':
        """Create a new QR token"""
        from secrets import token_urlsafe
        data = {
            'token': token_urlsafe(32),
            'session_id': session_id,
            'expires_at': (datetime.now() + timedelta(hours=expiry_hours)).isoformat()
        }
        result = supabase.table('qr_tokens').insert(data).execute()
        return cls(**result.data[0])

    @classmethod
    def validate(cls, token: str, session_id: str) -> bool:
        """Validate a QR token"""
        result = supabase.table('qr_tokens').select('*').eq('token', token).eq('session_id', session_id).execute()
        if not result.data:
            return False
        token_data = result.data[0]
        expires_at = datetime.fromisoformat(token_data['expires_at'])
        return datetime.now() < expires_at
