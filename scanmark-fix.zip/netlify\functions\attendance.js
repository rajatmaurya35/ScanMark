const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

exports.handler = async (event, context) => {
  const { token } = event.queryStringParameters || {};

  if (event.httpMethod === 'GET') {
    try {
      // Get session details
      const { data: session, error: sessionError } = await supabase
        .from('qr_tokens')
        .select('*')
        .eq('token', token)
        .single();

      if (sessionError || !session) {
        return {
          statusCode: 404,
          body: JSON.stringify({ error: 'Session not found' })
        };
      }

      // Check if expired
      if (new Date(session.expires_at) < new Date()) {
        return {
          statusCode: 400,
          body: JSON.stringify({ error: 'Session expired' })
        };
      }

      // Get attendance for this session
      const { data: attendance, error: attendanceError } = await supabase
        .from('attendance')
        .select('*')
        .eq('session_token', token)
        .order('created_at', { ascending: false });

      return {
        statusCode: 200,
        body: JSON.stringify({
          session,
          attendance: attendance || []
        })
      };
    } catch (error) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'Server error' })
      };
    }
  }

  if (event.httpMethod === 'POST') {
    try {
      const { student_id, student_name, latitude, longitude } = JSON.parse(event.body);

      const { data, error } = await supabase
        .from('attendance')
        .insert({
          student_id,
          student_name,
          session_token: token,
          latitude,
          longitude,
          created_at: new Date().toISOString()
        })
        .single();

      if (error) throw error;

      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          data
        })
      };
    } catch (error) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          success: false,
          error: 'Failed to record attendance'
        })
      };
    }
  }

  return {
    statusCode: 405,
    body: JSON.stringify({ error: 'Method not allowed' })
  };
};
