import os

# Production settings
PRODUCTION = os.environ.get('FLASK_ENV') == 'production'

# Template configuration
TEMPLATE_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
STATIC_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')

# Force template reloading in production
TEMPLATE_AUTO_RELOAD = True

# Debug settings
DEBUG = not PRODUCTION
