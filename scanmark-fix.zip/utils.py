import os
import json
import qrcode
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from geopy.distance import geodesic
from config import CAMPUS_LOCATIONS, OPENAI_API_KEY
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from config import (
    SMTP_SERVER, SMTP_PORT, SMTP_USERNAME,
    SMTP_PASSWORD, SMTP_FROM_EMAIL
)

def generate_qr_code(url: str, token: str) -> str:
    """Generate QR code and save it to static folder"""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(url)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")
    
    # Save QR code
    static_dir = os.path.join(os.path.dirname(__file__), 'static', 'qr_codes')
    os.makedirs(static_dir, exist_ok=True)
    file_path = os.path.join(static_dir, f'{token}.png')
    img.save(file_path)
    
    return f'/static/qr_codes/{token}.png'

def is_location_within_campus(lat: float, lng: float) -> bool:
    """Check if given coordinates are within campus boundaries"""
    point = (lat, lng)
    for campus in CAMPUS_LOCATIONS:
        center = (campus['center']['lat'], campus['center']['lng'])
        distance = geodesic(point, center).meters
        if distance <= campus['radius']:
            return True
    return False

def generate_attendance_report(session_id: str, format: str = 'csv') -> str:
    """Generate attendance report in specified format"""
    from models import Session
    
    session = Session.get_by_id(session_id)
    if not session:
        raise ValueError("Session not found")
    
    records = session.get_attendance_records()
    df = pd.DataFrame(records)
    
    # Format timestamp
    df['created_at'] = pd.to_datetime(df['created_at']).dt.strftime('%Y-%m-%d %H:%M:%S')
    
    # Save report
    reports_dir = os.path.join(os.path.dirname(__file__), 'static', 'reports')
    os.makedirs(reports_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'attendance_report_{session_id}_{timestamp}.{format}'
    file_path = os.path.join(reports_dir, filename)
    
    if format == 'csv':
        df.to_csv(file_path, index=False)
    elif format == 'xlsx':
        df.to_excel(file_path, index=False)
    elif format == 'pdf':
        # Use plotly to create a styled table
        fig = px.table(df, headers='keys', cells='values')
        fig.write_image(file_path)
    
    return f'/static/reports/{filename}'

def generate_performance_charts(student_id: str) -> Dict[str, str]:
    """Generate performance visualization charts"""
    from models import Student
    
    stats = Student.get_performance_stats(student_id)
    charts_dir = os.path.join(os.path.dirname(__file__), 'static', 'charts')
    os.makedirs(charts_dir, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # Attendance trend chart
    attendance_df = pd.DataFrame(stats['attendance_records'])
    if not attendance_df.empty:
        attendance_df['date'] = pd.to_datetime(attendance_df['created_at']).dt.date
        attendance_trend = attendance_df.groupby('date').size().reset_index(name='count')
        fig = px.line(attendance_trend, x='date', y='count', title='Attendance Trend')
        attendance_chart = f'attendance_trend_{student_id}_{timestamp}.png'
        fig.write_image(os.path.join(charts_dir, attendance_chart))
    else:
        attendance_chart = None
    
    # Performance chart
    performance_df = pd.DataFrame(stats['performance_records'])
    if not performance_df.empty:
        fig = px.bar(performance_df, x='subject', y='marks', title='Subject Performance')
        performance_chart = f'performance_{student_id}_{timestamp}.png'
        fig.write_image(os.path.join(charts_dir, performance_chart))
    else:
        performance_chart = None
    
    return {
        'attendance_chart': f'/static/charts/{attendance_chart}' if attendance_chart else None,
        'performance_chart': f'/static/charts/{performance_chart}' if performance_chart else None
    }

def send_email_report(to_email: str, subject: str, body: str, attachments: List[str] = None):
    """Send email with optional attachments"""
    msg = MIMEMultipart()
    msg['From'] = SMTP_FROM_EMAIL
    msg['To'] = to_email
    msg['Subject'] = subject
    
    msg.attach(MIMEText(body, 'html'))
    
    if attachments:
        for file_path in attachments:
            with open(file_path, 'rb') as f:
                part = MIMEApplication(f.read(), Name=os.path.basename(file_path))
                part['Content-Disposition'] = f'attachment; filename="{os.path.basename(file_path)}"'
                msg.attach(part)
    
    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
        server.starttls()
        server.login(SMTP_USERNAME, SMTP_PASSWORD)
        server.send_message(msg)

def get_ai_insights(student_data: Dict[str, Any]) -> str:
    """Generate AI insights using OpenAI"""
    import openai
    
    openai.api_key = OPENAI_API_KEY
    
    # Prepare context for AI
    context = {
        'attendance_rate': student_data['attendance_percentage'],
        'performance': student_data['performance_records'],
        'total_sessions': student_data['total_sessions']
    }
    
    prompt = f"""
    Based on the following student data:
    - Attendance Rate: {context['attendance_rate']}%
    - Total Sessions: {context['total_sessions']}
    - Performance: {json.dumps(context['performance'], indent=2)}
    
    Please provide:
    1. A brief analysis of the student's performance
    2. Areas of improvement
    3. Specific recommendations
    Keep the response concise and actionable.
    """
    
    try:
        response = openai.Completion.create(
            engine="gpt-3.5-turbo",
            prompt=prompt,
            max_tokens=200,
            temperature=0.7
        )
        return response.choices[0].text.strip()
    except Exception as e:
        print(f"Error generating AI insights: {e}")
        return "Unable to generate insights at this time."

def sync_with_google_calendar(session_data: Dict[str, Any], calendar_id: str):
    """Sync session with Google Calendar"""
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build
    
    # Calendar API setup
    SCOPES = ['https://www.googleapis.com/auth/calendar.events']
    
    try:
        flow = InstalledAppFlow.from_client_secrets_file(
            'client_secrets.json', SCOPES)
        creds = flow.run_local_server(port=0)
        
        service = build('calendar', 'v3', credentials=creds)
        
        event = {
            'summary': session_data['name'],
            'description': f"Faculty: {session_data['faculty']}\nBranch: {session_data['branch']}\nSemester: {session_data['semester']}",
            'start': {
                'dateTime': session_data['created_at'],
                'timeZone': 'Asia/Kolkata',
            },
            'end': {
                'dateTime': (datetime.fromisoformat(session_data['created_at']) + timedelta(hours=1)).isoformat(),
                'timeZone': 'Asia/Kolkata',
            },
        }
        
        event = service.events().insert(calendarId=calendar_id, body=event).execute()
        return event['id']
        
    except Exception as e:
        print(f"Error syncing with Google Calendar: {e}")
        return None
