# Import the Flask application
from app import app as application

# Force template reloading in production
application.config['TEMPLATES_AUTO_RELOAD'] = True
application.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

# For local development
if __name__ == '__main__':
    application.run()

# For Render deployment
app = application
