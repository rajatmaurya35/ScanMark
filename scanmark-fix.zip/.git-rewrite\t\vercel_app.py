from app import app

# Vercel requires the app to be named 'app'
app = app
