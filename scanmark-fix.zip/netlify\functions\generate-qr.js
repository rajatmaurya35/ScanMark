const { createClient } = require('@supabase/supabase-js');
const QRCode = require('qrcode');
const { v4: uuidv4 } = require('uuid');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

exports.handler = async (event, context) => {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const { session_name, faculty, branch, semester } = JSON.parse(event.body);
    const token = uuidv4();
    const session_str = `${session_name} - ${faculty} - ${branch} - ${semester}`;
    
    // Create QR token in Supabase
    const expires_at = new Date();
    expires_at.setHours(expires_at.getHours() + 24);

    const { data: tokenData, error: tokenError } = await supabase
      .from('qr_tokens')
      .insert({
        token,
        session: session_str,
        created_at: new Date().toISOString(),
        expires_at: expires_at.toISOString()
      })
      .single();

    if (tokenError) {
      throw tokenError;
    }

    // Generate QR code
    const qrUrl = `${process.env.URL}/attend/${token}`;
    const qrImage = await QRCode.toDataURL(qrUrl);

    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        token,
        qr: qrImage.split(',')[1] // Remove data:image/png;base64, prefix
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        success: false, 
        error: 'Failed to generate QR code' 
      })
    };
  }
};
