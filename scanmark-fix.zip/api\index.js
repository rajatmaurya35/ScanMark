const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const QRCode = require('qrcode');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const app = express();
const port = process.env.PORT || 3000;

// Supabase setup
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(express.static('static'));
app.use('/templates', express.static('templates'));

// Session middleware
app.use(session({
  secret: process.env.SECRET_KEY || 'scanmark-dev-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: process.env.NODE_ENV === 'production' }
}));

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../templates/admin/login.html'));
});

app.post('/admin/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const { data: admin } = await supabase
      .from('admins')
      .select()
      .eq('username', username)
      .single();

    if (!admin) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const validPassword = await bcrypt.compare(password, admin.password_hash);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    req.session.admin = username;
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/admin/dashboard', (req, res) => {
  if (!req.session.admin) {
    return res.redirect('/');
  }
  res.sendFile(path.join(__dirname, '../templates/admin/dashboard.html'));
});

app.post('/api/sessions/create', async (req, res) => {
  if (!req.session.admin) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const { faculty, branch, semester } = req.body;
    const token = uuidv4();
    const session = `${faculty}-${branch}-${semester}`;
    const qrCode = await QRCode.toDataURL(token);

    await supabase.from('qr_tokens').insert({
      token,
      session,
      created_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
    });

    res.json({ success: true, qrCode, token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/sessions', async (req, res) => {
  if (!req.session.admin) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const { data: sessions } = await supabase
      .from('qr_tokens')
      .select()
      .order('created_at', { ascending: false });

    res.json(sessions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/attendance', async (req, res) => {
  try {
    const { token, student_id } = req.body;
    
    const { data: qrToken } = await supabase
      .from('qr_tokens')
      .select()
      .eq('token', token)
      .single();

    if (!qrToken) {
      return res.status(400).json({ error: 'Invalid session' });
    }

    if (new Date(qrToken.expires_at) < new Date()) {
      return res.status(400).json({ error: 'Session expired' });
    }

    await supabase.from('attendance').insert({
      student_id,
      created_at: new Date().toISOString(),
      status: 'present'
    });

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/attendance/:token', async (req, res) => {
  if (!req.session.admin) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const { token } = req.params;
    const { data: attendance } = await supabase
      .from('attendance')
      .select()
      .eq('token', token);

    res.json(attendance);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/admin/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

// Start server
if (require.main === module) {
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

module.exports = app;
