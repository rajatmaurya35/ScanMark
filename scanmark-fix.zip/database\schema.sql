-- Enable necessary extensions
create extension if not exists "uuid-ossp";
create extension if not exists "postgis";

-- Sessions table
create table sessions (
    id uuid primary key default uuid_generate_v4(),
    name text not null,
    faculty text not null,
    branch text not null,
    semester text not null,
    active boolean default true,
    created_at timestamp with time zone default now(),
    admin_id text not null references admins(username)
);

-- Attendance table
create table attendance (
    id uuid primary key default uuid_generate_v4(),
    session_id uuid references sessions(id),
    student_id text not null,
    student_name text not null,
    timestamp timestamp with time zone default now(),
    location geometry(Point, 4326),
    device_info jsonb,
    ip_address text
);

-- Student Performance table
create table student_performance (
    id uuid primary key default uuid_generate_v4(),
    student_id text not null,
    subject text not null,
    marks numeric,
    max_marks numeric,
    exam_date date,
    created_at timestamp with time zone default now()
);

-- AI Insights table
create table ai_insights (
    id uuid primary key default uuid_generate_v4(),
    student_id text not null,
    insight_type text not null,
    content text not null,
    created_at timestamp with time zone default now()
);

-- Campus Locations table
create table campus_locations (
    id uuid primary key default uuid_generate_v4(),
    name text not null,
    boundary geometry(Polygon, 4326),
    created_at timestamp with time zone default now()
);

-- Create indexes
create index on sessions(admin_id);
create index on attendance(session_id);
create index on attendance(student_id);
create index on student_performance(student_id);
create index on ai_insights(student_id);

-- Create function to check if point is within campus
create or replace function is_within_campus(point geometry)
returns boolean as $$
begin
    return exists (
        select 1 from campus_locations
        where ST_Contains(boundary, point)
    );
end;
$$ language plpgsql;
