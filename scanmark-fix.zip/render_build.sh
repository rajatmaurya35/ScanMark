#!/bin/bash
# This script ensures templates are correctly deployed
echo "Ensuring templates are correctly deployed..."
mkdir -p $HOME/templates
cp -r templates/* $HOME/templates/
echo "Template deployment verified!"
