from supabase import create_client
from datetime import datetime, timedelta

SUPABASE_URL = 'https://aaluawvcohqfhevkdnuv.supabase.co'
SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFhbHVhd3Zjb2hxZmhldmtkbnV2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDIyNzY3MzcsImV4cCI6MjA1Nzg1MjczN30.kKL_B4sw1nwY6lbzgyPHQYoC_uqDsPkT51ZOnhr6MNA'

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

# Add sample sessions
sessions = [
    'Physics - Shilpa Mam - IT - 8th sem',
    'OOPS - Avani mam - Diploma - 3rd sem',
    'System Software - Vijay Sir - Computer - 6th sem'
]

for session in sessions:
    try:
        supabase.table('qr_tokens').insert({
            'token': session.lower().replace(' ', '-'),
            'session': session,
            'expires_at': (datetime.now() + timedelta(days=1)).isoformat()
        }).execute()
        print(f'Added session: {session}')
    except Exception as e:
        print(f'Error adding session {session}: {e}')

# Add sample attendance records
student_ids = [
    '211040107001',
    '211040107002',
    '211040107003'
]

for student_id in student_ids:
    try:
        # Add attendance for last 7 days
        for i in range(7):
            date = datetime.now() - timedelta(days=i)
            supabase.table('attendance').insert({
                'student_id': student_id,
                'created_at': date.isoformat(),
                'status': 'present'
            }).execute()
        print(f'Added attendance for student: {student_id}')
    except Exception as e:
        print(f'Error adding attendance for student {student_id}: {e}')

print('Sample data added successfully')
