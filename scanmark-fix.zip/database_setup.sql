-- Function to create qr_tokens table
create or replace function create_qr_tokens_table()
returns void
language plpgsql
as $$
begin
  create table if not exists qr_tokens (
    token text primary key,
    session text not null,
    faculty text not null,
    branch text not null,
    semester text not null,
    created_at timestamp with time zone default timezone('utc', now()),
    expires_at timestamp with time zone not null
  );
end;
$$;

-- Function to create attendance table
create or replace function create_attendance_table()
returns void
language plpgsql
as $$
begin
  create table if not exists attendance (
    id uuid primary key default uuid_generate_v4(),
    student_id text not null,
    created_at timestamp with time zone default timezone('utc', now()),
    status text default 'present'
  );
end;
$$;

-- Function to create admins table
create or replace function create_admins_table()
returns void
language plpgsql
as $$
begin
  create table if not exists admins (
    username text primary key,
    password_hash text not null,
    created_at timestamp with time zone default timezone('utc', now())
  );
end;
$$;
