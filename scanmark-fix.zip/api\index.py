from vercel_wsgi import make_handler
from app import app

# Create the Vercel serverless handler for the Flask app
handler = make_handler(app)
